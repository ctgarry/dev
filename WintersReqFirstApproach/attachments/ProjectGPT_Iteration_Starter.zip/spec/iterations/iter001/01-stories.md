# 01 — User Stories & Acceptance

- Story-1: As a <persona>, I want <capability> so that <value>.
  - AC-1.1 (Given/When/Then): …

- Story-2: …

**MoSCoW Priority:** Mark each story Must/Should/Could/Won’t (v1).
