# 02 — Functional & Non-Functional Requirements

## Functional Requirements (FR)
- **FR-1.** When <condition>, the system **must** <behavior>.
- **FR-2.** …

## Non-Functional (NFR)
- **NFR-1.** p95 < 100ms for <endpoint>.
- **NFR-2.** …
