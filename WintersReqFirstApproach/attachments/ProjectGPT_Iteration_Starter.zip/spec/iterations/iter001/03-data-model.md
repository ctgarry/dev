# 03 — Data Model & Contracts

## Entities (SV/DB)
```lua
-- New/changed fields only
WinterChecklistDB = {
  -- ...
}
```
## Migration
- Defaults: …
- Legacy flags/keys: …
- Never delete fields silently.

## Public Interfaces (if any)
```json
{ "endpoint": "/example", "request": {}, "response": {} }
```
