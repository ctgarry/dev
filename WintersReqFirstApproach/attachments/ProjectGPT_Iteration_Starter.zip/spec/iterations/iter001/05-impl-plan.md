# 05 — Implementation Plan

**Touchpoints (files):**
- path/to/file1.lua — reason
- path/to/file2.lua — reason

**Steps (small, reviewable):**
1) Defaults & migration (≤30 lines)
2) Helpers (≤40 lines/function)
3) UI handlers
4) i18n keys
5) Help popup
6) Tests / micro-verify
