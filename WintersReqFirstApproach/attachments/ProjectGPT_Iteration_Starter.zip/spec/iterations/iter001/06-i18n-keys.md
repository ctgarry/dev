# 06 — i18n Keys (enUS intent)

```lua
L.FEATURE_TITLE = "..."
L.FEATURE_TIP   = "..."
L.FEATURE_HELP_TITLE = "..."
L.FEATURE_HELP_BODY  = [[
...
]]
L.BTN_OK = "OK"
```
