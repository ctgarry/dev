# 08 — Test Plan

## Environment
- Classic Era (Retail if applicable)

## Smoke
- Load, open, toggle, reload

## Feature Tests
- Map FR-IDs → checks

## Edge Cases
- Empty SV, migration, cancel flows, combat lockdown

## Go/No-Go
- 4–6 bullets to ship
