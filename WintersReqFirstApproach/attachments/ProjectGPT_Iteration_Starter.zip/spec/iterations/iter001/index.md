# Iteration 001 — Index

Fill these files in order. Keep each section concise and testable.

1. 00-charter.md
2. 01-stories.md
3. 02-fr-nfr.md
4. 03-data-model.md
5. 04-ux.md
6. 05-impl-plan.md
7. 06-i18n-keys.md
8. 07-acceptance.md
9. 08-test-plan.md
10. 09-codex-steps.md
