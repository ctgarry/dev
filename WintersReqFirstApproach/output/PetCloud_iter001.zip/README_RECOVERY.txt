Resume-Later Instructions:
Save this .zip locally. When you reopen ChatGPT, upload it and say:
'Reload my ProjectGPT iteration from this zip.'
I'll restore the spec files and resume at the next step.
