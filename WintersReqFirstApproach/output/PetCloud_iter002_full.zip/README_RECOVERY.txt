=========================================
 ProjectGPT — Resume-Later Instructions
=========================================

💾 HOW TO SAVE YOUR WORK
------------------------
1. Keep this .zip file in a safe local folder (e.g., Documents/ProjectGPT/).
2. This file contains all iteration markdowns for your current project.

🧩 HOW TO RESUME LATER
----------------------
When you open ChatGPT again in a new session or window:
1. Upload this same .zip file.
2. Say exactly:
   > "Reload my ProjectGPT iteration from this zip."
3. ProjectGPT will detect your iteration folder (e.g., spec/iterations/iter002_full/)
   and restore the full project context automatically.

📂 WHAT HAPPENS NEXT
--------------------
- You’ll see a summary of recovered files (00-charter.md, 01-stories.md, etc.).
- You can then continue from the next logical step (e.g., 04-ux.md).

💡 TIPS
-------
- You can always repackage your progress after major updates.
- To check that the recovery worked, ask:
  > "Show me the recovered iteration summary."

🔐 DATA SAFETY
--------------
- All project data lives inside this .zip.
- ChatGPT sessions do not persist automatically — your local zip is the single
  source of truth.
- No cloud sync or remote upload is performed.

🧰 Helper Macro: ResumeGuide
----------------------------
> **Resume-Later Instructions:** Save the `.zip`, reopen ChatGPT, upload it, and say "Reload my ProjectGPT iteration from this zip."

-----------------------------------------
 End of README_RECOVERY.txt
-----------------------------------------
