## 1. Project Charter — PetCloud (WoW Retail Addon)
**Vision.** Elevate the in-game Pet Journal with smarter organization, reminders for pet-related events, achievement guidance, and delightful auto-summon rules — all fully offline and compliant with Blizzard API constraints.

**Problem.** The default journal makes advanced collection management tedious: weak filtering, limited notes, no event awareness, and no “set-and-forget” summon behavior.

**Objectives (this iteration).**
1) Ship **Journal+** (tags, groups, notes, filters) and **Summon Rules** (contextual auto-summon).  
2) Add **Event Reminders** (Darkmoon Faire, weeklies, world quests), **Achievement Guidance**, and **Import/Export** sharables.  
3) Ensure **zero taint**, **saved data persistence**, and **localization-ready** strings.

**In-Scope (feature sets).**
- **A. Journal+:** custom tags, groups, notes, advanced filters/search.  
- **B. Planner & Reminders:** event calendar (in-game), configurable alerts.  
- **C. Summon Rules:** rotation and context triggers (login, zone, mount, time-of-day, holiday).  
- **D. Achievements Guide:** progress views, missing-by-source, suggested targets.  
- **E. Share & Presets:** import/export strings, chat links, one-click apply.  

**Out-of-Scope.**
- External web services, cloud sync, real-money features, and guild-wide data storage.  
- Player-to-player mail automation (restricted), cross-realm persistence.

**Personas.**
- **Collector Casey:** wants to finish pet sets with minimal friction.  
- **Explorer Echo:** loves ambient pets matched to zones/holidays.  
- **Optimizer Onyx:** seeks fast filters and achievement progress clarity.

**Constraints & Assumptions.**
- **Environment:** WoW Retail (11.x), Lua addon with SavedVariables.  
- **APIs:** Uses Blizzard events (e.g., `PLAYER_LOGIN`, `PET_JOURNAL_LIST_UPDATE`, `ZONE_CHANGED_NEW_AREA`).  
- **No External I/O:** No HTTP, no sockets. Data lives in SavedVariables.  
- **Performance:** Avoid UI taint; minimal per-frame CPU; throttle scanning.

**Success Metrics.**
- Time-to-find-a-pet (search/filter) reduced by 40%.  
- ≥50% of users configure ≥1 summon rule within 7 days.  
- ≥30% use reminders for at least one recurring event.  
- Zero “taint” issues reported in standard interactions.
