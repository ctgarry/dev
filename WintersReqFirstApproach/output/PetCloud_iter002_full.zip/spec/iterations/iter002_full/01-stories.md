## Story Map (MoSCoW)
**Must-Have**
- S1. As a player, I can tag pets, group them, and add notes viewable in the journal.  
- S2. As a player, I can filter/search pets by family, source, zone, rarity, collected/missing, tag(s).  
- S3. As a player, I can configure **Summon Rules** that auto-summon on login/zone/holiday/mount states.  
- S4. As a player, I can view pet-related **event reminders** (e.g., Darkmoon Faire window, weekly activities) and receive in-game alerts.  
- S5. As a player, I can track **achievement** progress with missing-by-source guidance.  
- S6. As a player, I can import/export **preset lists** via clipboard/chat strings.

**Should-Have**
- S7. As a player, I can rotate favorites automatically with weighted randomness.  
- S8. As a player, I can quick-toggle per-character vs account-wide settings.

**Could-Have**
- S9. As a player, I can pin “today’s targets” for quick access.  

**Won’t-Have (this iteration)**
- S10. Cross-character automatic synchronization (beyond standard SavedVariables).  

## Acceptance (key Given/When/Then excerpts)
- **S1 Journal+:** Given a pet, when I add a note/tag/group, then it persists across reload and appears in the journal detail panel.  
- **S2 Filters:** Given a multi-criteria filter, when applied, then results update within 150 ms and reflect correct set membership.  
- **S3 Summon Rules:** Given a “zone=Dragon Isles” rule, when entering that zone, then a pet is summoned per rule priority without taint.  
- **S4 Reminders:** Given Darkmoon Faire active window, when the window starts, then I receive a single non-spam alert with dismiss/snooze.  
- **S5 Achievements:** Given an achievement target, when opened, then missing pets list with source hints is shown.  
- **S6 Import/Export:** Given a valid preset string, when imported, then tags/groups are added (preview before apply).
