## Functional Requirements (FR)
**Journal+**
- **FR-001.** System **must** store per-pet `tags[]`, `groups[]`, and `note` in SavedVariables (account scope by default; character override optional).  
- **FR-002.** Detail panel **must** display note and tags; list view **must** filter by multiple tags with AND/OR logic.  
- **FR-003.** Advanced search **must** support family, source, rarity, collected/missing, name, tag, group.

**Planner & Reminders**
- **FR-010.** System **must** maintain an in-game schedule of pet-relevant events (e.g., Darkmoon Faire, PvE pet week, weekly resets).  
- **FR-011.** Reminders **must** be configurable (on/off per event, alert at start/24h prior), and **must not** repeat after dismissal until the next event window.  
- **FR-012.** A compact **Today/This Week** panel **must** summarize active/soon events.

**Summon Rules**
- **FR-020.** Players **must** define rules with triggers: `onLogin`, `onZoneChange`, `onHoliday`, `onMounted`, `onTimeRange`.  
- **FR-021.** Rules **must** select from: specific pet(s), group, tag, or **rotation** with optional weights.  
- **FR-022.** Conflicts **must** resolve by explicit priority order; last matching rule wins.

**Achievements Guide**
- **FR-030.** System **must** display tracked achievements with owned/missing breakdown and hints (source, zone, vendor, drop).  
- **FR-031.** “Suggest Next” **must** recommend up to 5 pets based on proximity to completion.

**Share & Presets**
- **FR-040.** System **must** export/import presets as compact strings representing tags, groups, and summon rules.  
- **FR-041.** Import **must** show a **preview** (diff) and request confirm/cancel.

**General**
- **FR-050.** Minimap button and `/petcloud` slash command **must** open the main UI.  
- **FR-051.** Tooltips **must** render tag/group info where pet links/tooltips appear (where safe to hook).

## Non-Functional Requirements (NFR)
- **NFR-001 Compliance.** **No taint** in combat or standard UI flows; use secure hooks only.  
- **NFR-002 Performance.** Filter operations P95 ≤ 150 ms on 1,500+ pets; idle CPU usage negligible.  
- **NFR-003 Persistence.** SavedVariables writes are atomic per session; data schema versioned and migrated on load.  
- **NFR-004 UX.** All actions ≤ 3 clicks; keyboard focus cycles through search and tag fields.  
- **NFR-005 Localization.** All user-visible strings behind i18n keys; English default.  
- **NFR-006 Accessibility.** High-contrast option for lists and reminders panel.  
- **NFR-007 Safety.** Import preview prevents destructive overwrites by default.  
- **NFR-008 Compatibility.** Retail 11.x; fails gracefully on PTR/beta with version notice.
