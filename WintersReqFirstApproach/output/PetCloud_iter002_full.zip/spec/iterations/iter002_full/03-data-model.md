## SavedVariables (schema v2)
```lua
PetCloudDB = {
  version = 2,
  account = {
    pets = {
      [petGUID] = {
        tags = { "holiday", "dragon", ... },
        groups = { "raiding", "leveling" },
        note = "Dropped in X zone",
      },
    },
    summonRules = {
      -- ordered list; last match wins
      { id="r1", trigger="onZoneChange", match={ zoneId=XXXX }, select={ type="group", name="dragon" }, weight=1 },
      { id="r2", trigger="onLogin", select={ type="rotation", list={"petGUID1","petGUID2"}, weights={1,2} } },
    },
    presets = {
      -- named sets for share/import/export
      ["Holiday Set"] = { tags={...}, groups={...}, rules={...} },
    },
    reminders = {
      events = {
        DarkmoonFaire = { enabled=true, alertAtStart=true, alert24hPrior=true },
        PetBattleWeek = { enabled=true },
      }
    },
    options = { locale="enUS", characterOverrides=false, highContrast=false },
  },
  character = {
    -- per-character overrides if enabled
  }
}
```

## Internal Tables (in-memory)
- `IndexByTag`, `IndexByGroup`, `IndexByFamily`, `IndexBySource`, `IndexByRarity`.  
- `EventCalendar` (computed for current realm time).  
- `AchvTracker` (selection of tracked achievements and computed gaps).

## Migration
- v1 → v2: add `reminders.events`, `presets`, and `weights` in `summonRules`; backfill defaults; log one-time notice.
