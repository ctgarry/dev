## Touchpoints (file-level, no code)
- `PetCloud.toc` — addon manifest.  
- `core/` load order, SavedVariables init, version migrations.  
- `ui/` JournalPlus, Planner, Rules, Achievements, Settings frames.  
- `features/` filters, reminders, summon, presets, import/export, tooltips.  
- `data/` event calendar helpers, achievement maps.  
- `i18n/` string tables by locale.  

## Steps (≤6; each step stays within light-diff limits)
1) **Core + SavedVariables v2** — init DB, migrations, `/petcloud`, minimap button.  
2) **Journal+ & Filters** — tags/notes/groups storage + UI, multi-criteria search, tooltips integration.  
3) **Summon Rules** — triggers (login/zone/holiday/mounted/time), selection logic, priority resolution, test summon.  
4) **Planner & Reminders** — event calendar computation, banner/toast alerts, Today/ThisWeek panel.  
5) **Achievements Guide** — progress views, missing-by-source mapping, “Suggest Next”.  
6) **Share & Presets + i18n** — import/export strings with preview; finalize locales; performance pass.
