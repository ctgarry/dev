```
app.title
app.minimap.tooltip
app.open
app.reset_filters

journal.title
journal.search.placeholder
journal.filter.family
journal.filter.source
journal.filter.rarity
journal.filter.collected
journal.filter.tag
journal.filter.group
journal.tags.add
journal.groups.add
journal.note.add
journal.tooltip.tags
journal.tooltip.groups
journal.no_results

rules.title
rules.new
rules.trigger.login
rules.trigger.zone
rules.trigger.holiday
rules.trigger.mounted
rules.trigger.time
rules.select.pet
rules.select.group
rules.select.tag
rules.select.rotation
rules.priority
rules.test
rules.saved
rules.disabled_in_combat

planner.title
planner.darkmoon_faire
planner.pet_battle_week
planner.alert.start
planner.alert.prior24h
planner.today
planner.this_week
planner.alert.banner
planner.alert.snooze
planner.alert.dismiss

achv.title
achv.progress
achv.missing_by_source
achv.suggest_next

presets.title
presets.export
presets.import
presets.preview
presets.apply
presets.cancel
presets.success

settings.title
settings.account_wide
settings.character_override
settings.high_contrast
settings.locale
```
