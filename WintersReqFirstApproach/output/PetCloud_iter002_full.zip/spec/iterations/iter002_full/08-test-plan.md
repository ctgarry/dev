## Smoke
- `/petcloud` and minimap open main UI; no errors in chat.  
- Add a note/tag; `/reload` → data persists.  
- Create a login summon rule; relog → pet summoned.

## Feature Tests
- **Filters:** Combine family+rarity+tag; verify count and contents; clear-all resets.  
- **Summon Rules:** Multiple rules with priority; zone change triggers last-match; mounted trigger behaves; disabled in combat.  
- **Reminders:** Adjust alert toggles; verify banner at event start and prior-24h; snooze/dismiss behavior.  
- **Achievements:** Choose achievement; owned/missing correct; suggestion list valid.  
- **Import/Export:** Export preset; paste to a fresh profile; preview diff accurate; cancel/apply respect expectations.

## Edge Cases
- Combat lockdown: test summon blocked in combat; proper message shown.  
- Holiday detection mismatch: fallback to calendar check without spam alerts.  
- Massive tag lists (>50): UI remains scrollable, no script timeout.  
- Corrupt import string: parse error surfaced; no DB mutation.
