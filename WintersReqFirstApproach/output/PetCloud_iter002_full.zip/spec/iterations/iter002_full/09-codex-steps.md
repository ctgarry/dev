**Strict Light-Diff Steps (STOP/WAI after each)**

**Step 01 — Core & DB**
- ADD `PetCloud.toc`; INIT SavedVariables v2; add `/petcloud`; minimap button; version migration notice.

**Step 02 — Journal+ & Filters**
- ADD storage for tags/groups/notes; UI for detail panel; multi-criteria filter bar; tooltip hook (safe).

**Step 03 — Summon Rules**
- ADD triggers (login/zone/holiday/mounted/time); selection (pet/group/tag/rotation + weights); priority resolution; “Test” action (non-combat).

**Step 04 — Planner & Reminders**
- ADD event calendar calculators; Today/ThisWeek panel; alerts (banner/toast) with snooze/dismiss; throttle to prevent spam.

**Step 05 — Achievements Guide**
- ADD progress view; missing-by-source map; “Suggest Next” heuristic.

**Step 06 — Share & Presets + i18n**
- ADD export/import string codec; preview diff; merge-on-apply; finalize i18n keys and localization scaffolding.
