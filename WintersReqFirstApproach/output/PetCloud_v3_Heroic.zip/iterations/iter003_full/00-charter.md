# PetCloud v3 — Heroic Release (Cumulative Spec)
**Iteration:** iter003_full  ·  **Date:** 2025-10-19  ·  **Mode:** Safety‑Net v2

## 1. Problem
Players face paralysis when browsing 1500+ pets. The worst pain is helplessness: “I don’t know what to use today.”
Static lists don’t react to player context (zone, quest, event, battle) or personal habits; the result is decision fatigue.

## 2. Vision
Transform PetCloud from a static catalog into an *intelligent companion* that notices context, learns preferences, and
recommends 3–5 meaningful options at any moment. Reduce time-to-choice and increase the sense of discovery.

## 3. Goals
- Time-to-choice **p50 ≤ 10 s**, **p90 ≤ 20 s** after opening PetCloud.
- Provide **situational recommendations** that adapt to zone, quest, event, and enemy family.
- Personalize results via **Intent Engine**, **Adaptive Tags**, **Mood**, **Meta trends**, and **Synergy Graph**.
- Ship a cumulative, localization‑ready specification set with validation mapping and codex anchors.

## 4. Non‑Goals
- No external network calls required in v3 (optional feeds are stubbed for future v4).
- No automation during combat lockdown; only hints and safe UI.
- No server-side ML; logic is local and deterministic.

## 5. Scope
### In
Situational Recommendations, Intent Engine, Adaptive Tag Cloud, Guided Search Wizard, Mood Selector, Smart Tag Generator,
Synergy Graph, Meta Snapshot, i18n keys, acceptance mapping, edge‑matrix tests, codex light‑diff plan.

### Out
Cloud trend sync and voice control (planned for v4+).

## 6. Personas
- **Battler Ben**: wants strong counters and winning teams quickly.
- **Collector Cora**: wants to fill gaps and level pets efficiently.
- **Stylist Sera**: wants a pet that matches today’s vibe.
- **Newcomer Nix**: wants safe defaults and clear explanations.

## 7. Constraints
Respect WoW Retail API constraints and secure environments; disable protected actions during combat.
Saved variables budget: ≤100 KB for new modules. Context change latency target: ≤2 s (p95).

## 8. Success Metrics
- ≥70% of sessions accept at least one situational suggestion.
- ≥80% of user‑visible strings routed through i18n keys.
- No frame update exceeding 5 ms on average during refresh.
