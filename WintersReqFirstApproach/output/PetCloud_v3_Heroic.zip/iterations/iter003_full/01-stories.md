# User Stories (MoSCoW + Gherkin Acceptance)

## Must‑Have
### US‑M1 — Situational pet suggestions during Pet Battle
**As** a Battler **I want** suggestions that counter the current enemy family **So that** I can pick a winning team fast.

**Acceptance (GWT)**
- **Given** I enter a Pet Battle and the enemy’s active family is Mechanical
- **When** the battle UI appears
- **Then** PetCloud must surface 3–5 Elemental pets I own, each with a “Why” hint.

### US‑M2 — Zone/Quest/Event aware recommendations
**Given** I enter a new zone or accept a World Quest or a holiday is active
**When** PetCloud detects the change
**Then** I must see a refreshed shortlist matching the context within 2 seconds.

### US‑M3 — Manual intent override
**Given** I open the Guided Wizard
**When** I select “Leveling” intent
**Then** recommendations must prioritize under‑25 rare pets with XP synergies.

## Should‑Have
### US‑S1 — Mood selector
**When** I choose “Cute & Cozy”
**Then** results bias toward small playful critters with soft aesthetics.

### US‑S2 — Adaptive tag cloud
**Given** I have summoned Mechanical pets 10+ times this week
**Then** the “mechanical” tag should increase prominence and weighting.

## Could‑Have
### US‑C1 — Synergy graph exploration
**When** I click a pet in the graph
**Then** I can add it to a team tray and see top synergy partners.

### US‑C2 — Meta snapshot motivation
**Then** I can see “This Week’s Favorites” and “Ignored Recently” lists.

## Won’t‑Have (v3)
Cloud‑shared meta (deferred to v4).
