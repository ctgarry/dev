# Functional & Non‑Functional Requirements (Traceable)

## Functional Requirements
- **FR‑1 (Situational Core).** On zone/quest/event change, the system **must** compute and display 3–5 contextual pet suggestions with a rationale line. (Stories: US‑M2)
- **FR‑2 (Battle Counter).** During Pet Battle, the system **must** suggest pets strong vs the current enemy family. (US‑M1)
- **FR‑3 (Intent Engine).** The system **must** infer intent (Battle‑Win, Level‑Up, Collect‑All, Show‑Off, Explore‑Event) and provide a confidence value 0..1. Manual override persists until reset. (US‑M3)
- **FR‑4 (Guided Wizard).** Wizard **must** translate answers into filter predicates and apply them live. (US‑M3)
- **FR‑5 (Mood Selector).** Selecting a mood **must** bias results via tag and aesthetic weights. (US‑S1)
- **FR‑6 (Adaptive Tag Cloud).** Tag weights **must** be updated from usage logs each session and decay weekly. (US‑S2)
- **FR‑7 (Smart Tag Generator).** On scan or data change, the system **must** generate deterministic tags from family/ability/source/rarity. (US‑M2/S2)
- **FR‑8 (Synergy Graph).** The system **should** render a pet‑to‑pet synergy visualization and allow adding nodes to a team tray. (US‑C1)
- **FR‑9 (Meta Snapshot).** The system **should** compute weekly local trends with decay and present top/ignored lists. (US‑C2)
- **FR‑10 (i18n).** All user‑visible strings **must** resolve through i18n keys.

## Non‑Functional Requirements
- **NFR‑1 Performance.** Context refresh **must** complete within 2 s (p95) and avoid UI flicker via throttling (≥1 s).
- **NFR‑2 Safety.** No insecure operations during combat lockdown; features degrade gracefully.
- **NFR‑3 Footprint.** Saved variables growth ≤100 KB added in v3; per‑frame update ≤5 ms average.
- **NFR‑4 Determinism.** Tag generation and recommendations must be reproducible given the same inputs.
- **NFR‑5 Accessibility.** Provide readable tooltips and avoid color‑only meaning; keyboard navigation for wizard.
- **NFR‑6 Localization.** ≥80% coverage with English fallback; no hard‑coded strings.
