# Data Model & Contracts (Additions)

## Entities
### PetCloudIntent
- `id`: enum {INT‑001..INT‑005}
- `confidence`: 0..1
- `derivedFrom`: string[] (signals)
- `suggestedFilters`: string[]
- Defaults: `id="INT‑002"`, `confidence=0.5`

### PetCloudMood
- `moodID`: enum {M‑001..M‑005}
- `colorTheme`: hex
- `soundProfile`: enum {soft, epic, spooky, calm, metallic}
- `weightTags`: string[]

### PetCloudTags
- `petID`: number
- `tags`: string[]
- `source`: enum {auto, manual}
- `genVersion`: number — deterministic generator version

### PetSynergyCache
- key: petID
- value: map(partnerID → {score: 0..1, reason: string})

### PetCloudMeta
- `usage`: map(petID → count, lastUsedAt)
- `tagUsage`: map(tag → count)
- Decay: half‑life 7 days

## Persistence
Saved Variables table `PetCloudDBv3` with sub‑tables for each entity.
Eviction policy caps memory; least‑recent usage pruned first.

## Back‑Compat
Migrate v2 TagCloud weights into `tagUsage` with default decay applied on first run.
