# Implementation Plan (Codex Light‑Diff Anchors)

## Touchpoints
- `core/context.lua` — situation detectors, throttling
- `core/intent.lua` — intent inference & manual override
- `core/tags.lua` — smart tag generator + adaptive weights
- `ui/panel_context.lua` — floating panel
- `ui/wizard.lua` — guided search
- `ui/mood.lua` — mood wheel
- `data/synergy.lua` — synergy scoring & cache
- `data/meta.lua` — trend decay and snapshot

## Steps (≤30 changed lines per file)
1. **Anchor A:** Add event bus + throttled dispatcher in `core/context.lua`.
2. **Anchor B:** Implement intent inference skeleton with confidence output in `core/intent.lua`.
3. **Anchor C:** Port tag generation rules and unit tests in `core/tags.lua`.
4. **Anchor D:** Render minimal Context Panel with three static cards; then bind to live data.
5. **Anchor E:** Add Wizard state machine and predicate builder.
6. **Anchor F:** Implement Mood weights, bind to results, add toggle in settings.
7. **Anchor G:** Add synergy scorer and simple graph view; cache results.
8. **Anchor H:** Add Meta decay loop and dashboard widget.
9. **Anchor I:** Replace all hard strings with `L.KEY` and generate `06-i18n-keys.md`.
10. **Anchor J:** Wire acceptance telemetry and finalize options panel.

Each step ends with STOP/WAI for review.
