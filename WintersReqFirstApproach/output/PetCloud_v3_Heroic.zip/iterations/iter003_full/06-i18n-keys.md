# i18n Keys (enUS intent)

```
L.CONTEXT_TITLE = "Recommended for right now"
L.CONTEXT_REASON = "Why: %s"
L.MOOD_PICKER = "Pick a vibe"
L.MOOD_CUTE = "Cute & Cozy"
L.MOOD_EPIC = "Epic & Powerful"
L.MOOD_SPOOKY = "Spooky & Mysterious"
L.MOOD_TRANQUIL = "Tranquil & Natural"
L.MOOD_MECH = "Mechanical & Futuristic"
L.WIZARD_TITLE = "Find your pet"
L.WIZARD_PURPOSE = "What’s your goal today?"
L.WIZARD_RESULTS = "Results"
L.TEAM_TRAY = "Team Tray"
L.META_PANEL = "This Week’s Favorites"
L.IGNORED_PANEL = "Ignored Recently"
```
Notes: UI text lives here only; microcopy in UX file references these keys.
