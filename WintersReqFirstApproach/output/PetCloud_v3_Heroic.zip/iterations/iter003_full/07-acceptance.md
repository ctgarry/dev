# Acceptance Criteria (Validation Mapping)

| FR | Test ID | Given | When | Then |
|----|---------|-------|------|------|
| FR‑1 | AC‑01 | Zone change detected | Panel appears | 3–5 contextual pets with rationale within 2 s |
| FR‑2 | AC‑02 | Enemy family = Mechanical | Battle UI shows | Elemental counters listed with “Why” hint |
| FR‑3 | AC‑03 | Last 10 actions imply Level‑Up | Intent recalculated | Intent=Level‑Up with confidence ≥0.6 |
| FR‑4 | AC‑04 | Wizard answers set | Apply filters | Results reflect predicates and show explanation |
| FR‑5 | AC‑05 | Mood set to Cute | Suggestions render | Cute‑weighted pets rise to top 3 |
| FR‑6 | AC‑06 | Summon mechanical 10× this week | Open tag cloud | “mechanical” tag appears larger and weights results |
| FR‑7 | AC‑07 | New pet scanned | Tags generated | Deterministic tags include family and role |
| FR‑8 | AC‑08 | Open synergy view | Hover node | Top 3 partners highlighted with reason tooltip |
| FR‑9 | AC‑09 | One week of usage | Open dashboard | Favorites & Ignored lists reflect decay algorithm |
| FR‑10 | AC‑10 | UI renders | Inspect strings | All strings resolve via i18n keys |

Exit Criteria: All AC pass on Retail build with combat lockdown respected.
