# Test Plan — Smoke / Feature / Edge Matrix

## Smoke
- Load addon with no saved variables → UI loads, no errors.
- Enter/leave zone rapidly → panel throttles, no flicker.
- Toggle moods and wizard → results update and rationale present.

## Feature Tests
- Situational: validate per situation trigger (zone, quest, event, battle).
- Intent: simulate sequences to reach each intent with expected confidence.
- Tags: run generator on sample pets; verify deterministic outputs.
- Synergy: compute scores; ensure stable ordering and caching.
- Meta: log actions; verify decay and snapshot summaries.

## Edge Matrix (excerpt)
| Input | State | Outcome |
|-------|-------|---------|
| Zone change x5 in 3 s | throttle on | single refresh | 
| No Elemental pets owned | enemy=Mechanical | show acquisition tips / alt counters |
| Mood + Wizard conflict | both active | Wizard overrides; show banner |
| Combat lockdown | battle start | UI hints only; no protected actions |
| Empty roster (new player) | any | safe defaults + tutorial hints |

Regression: Maintain performance p95 < 2 s per refresh; saved vars < 100 KB.
