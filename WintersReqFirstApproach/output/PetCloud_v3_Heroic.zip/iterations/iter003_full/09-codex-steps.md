# Codex Steps — Strict Light‑Diff

**Rules:** ≤30 changed lines per step; edit only listed files; STOP/WAI after each.

1. core/context.lua — ADD event dispatcher + throttle (NEW)
2. core/intent.lua — ADD intent skeleton with confidence and override API (NEW)
3. core/tags.lua — ADD generator (rules TG‑001..TG‑007) and weight update (NEW)
4. ui/panel_context.lua — ADD minimal panel + bind to context feed (NEW)
5. ui/wizard.lua — ADD state machine + predicate builder (NEW)
6. ui/mood.lua — ADD mood wheel + weight bias (NEW)
7. data/synergy.lua — ADD scorer + cache; expose top partners (NEW)
8. data/meta.lua — ADD decay and snapshot functions (NEW)
9. i18n/enUS.lua — REPLACE hard strings with keys; ensure coverage (EDIT)
10. options.lua — ADD toggles; wire telemetry (EDIT)

Each step concludes with a checkpoint and functional demo proof.
