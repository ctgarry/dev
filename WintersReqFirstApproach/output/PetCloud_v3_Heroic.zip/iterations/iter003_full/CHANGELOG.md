# CHANGELOG — PetCloud v3 Heroic (iter003_full)

## Overview
Cumulative release adding the Heroic Discovery Intelligence layer and integrating all prior features.

## Additions
- Situational Recommendation System (zone/quest/event/battle aware)
- Intent Engine (Battle‑Win, Level‑Up, Collect‑All, Show‑Off, Explore‑Event)
- Adaptive Tag Cloud with weekly decay
- Guided Search Wizard and Mood Selector
- Smart Tag Generator (deterministic rules)
- Synergy Graph (team composition)
- Meta Snapshot (local trends)

## Enhancements
- Cross‑Iteration Traceability, Validation Mapping
- Codex Light‑Diff Anchors for safe implementation
- i18n auto‑keys; Accessibility and Performance targets

## Migration
Tag weights from v2 are migrated to `tagUsage` with decay applied on first run.
