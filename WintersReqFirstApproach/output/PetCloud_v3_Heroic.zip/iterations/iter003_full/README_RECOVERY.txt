=========================================
 ProjectGPT — Resume-Later Instructions
=========================================

HOW TO SAVE YOUR WORK
1. Keep this .zip file in a safe local folder (e.g., Documents/ProjectGPT/).
2. This file contains all iteration markdowns for your current project.

HOW TO RESUME LATER
1. Upload this same .zip file.
2. Say exactly: "Reload my ProjectGPT iteration from this zip."
3. ProjectGPT will detect your iteration folder (spec/iterations/iter003_full/) and restore context.

WHAT HAPPENS NEXT
- You’ll see a summary of recovered files (00-charter.md, 01-stories.md, etc.).
- Continue from the next logical step (e.g., 04-ux.md).

DATA SAFETY
- All project data lives inside this .zip.
- Sessions do not persist; your local zip is the single source of truth.
