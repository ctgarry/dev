# ROADMAP — Post‑v3

## v4 Legendary (Community & Archetypes)
- Community Trend Sync (opt‑in)
- Player Archetype Learning (Battler/Collector/Stylist)
- Team import/export share codes
- Contextual dialogue helper
- Recommendation Journal history
- Cross‑character memory

## v5+ Mythic (R&D)
- AR/Voice experiments
- Pet personality emotes
- Seasonal UI themes
- PetCloud SDK for plugins
