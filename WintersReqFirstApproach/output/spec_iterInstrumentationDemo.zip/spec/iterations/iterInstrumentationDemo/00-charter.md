# Iteration: Instrumentation Demo Specification (Simulated Data)

## Problem
The Engagement Tracker (iterMetrics) defines *what* to log, but stakeholders need a clear view of *how* those logs appear in practice and how summaries are presented without exposing private content.

## Vision
Create a self-contained, privacy-safe demonstration that simulates a small dataset (sessions, completions, exports, resumes) and defines how a Markdown “Mini Engagement Dashboard” is generated locally.

## Scope
- **In scope:** Sample event generation (simulated), local-only JSON and Markdown artifacts, a dashboard-spec for summary rendering.
- **Out of scope:** Real-time analytics, network services, or message-level logging.

## Non-goals
- No external APIs or telemetry uploads.
- No personal identifiers, no content capture.

## Constraints
- Must align with iterMetrics data model.
- Must run without dependencies (Markdown + JSON specs only).

## Personas
- **Builder:** Wants a concrete example of the metrics output.
- **Maintainer:** Needs acceptance criteria for verifying the summary’s correctness.
- **Auditor:** Needs traceability from simulated events to calculated metrics.

## Success Criteria
- A deterministic simulated dataset.
- A clearly specified Markdown “Mini Dashboard”.
- Acceptance checks that can be executed manually against the simulated artifacts.
