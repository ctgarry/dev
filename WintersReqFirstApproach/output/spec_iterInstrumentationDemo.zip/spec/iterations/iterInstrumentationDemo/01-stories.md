# User Stories — Instrumentation Demo

## Story 1 — Simulate Session Activity
**As a** maintainer  
**I want** a deterministic set of engagement events  
**So that** I can verify summaries and charts without touching real user data.

### Acceptance Criteria
- Given the demo is initialized, then `metrics_demo.json` (demo) contains 5 sessions, 3 completions, 4 safe exports, and 2 resumes.

---

## Story 2 — Generate Mini Engagement Dashboard
**As a** builder  
**I want** a Markdown dashboard summarizing totals and trends  
**So that** I can quickly review engagement quality.

### Acceptance Criteria
- The dashboard renders totals, a simple trend table, and a “key insights” block computed from demo data.

---

## Story 3 — Privacy Banner
**As an** auditor  
**I want** a clear privacy statement on the dashboard  
**So that** it’s obvious the data is simulated and local-only.

### Acceptance Criteria
- The dashboard includes a top-line banner stating: “Simulated, local-only dataset. No personal identifiers.”

---

## Story 4 — Export Readiness
**As a** user  
**I want** the demo artifacts to be included in Safety-Net packaging  
**So that** I can store and reload the example later.

### Acceptance Criteria
- The iteration’s demo files are included in the export and survive reload.

---

## Story 5 — Deterministic Regeneration
**As a** maintainer  
**I want** the demo data to be reproducible  
**So that** every run generates the same counts and dates.

### Acceptance Criteria
- Event timestamps are fixed (ISO 8601) within a defined 7-day window; recomputations produce identical results.
