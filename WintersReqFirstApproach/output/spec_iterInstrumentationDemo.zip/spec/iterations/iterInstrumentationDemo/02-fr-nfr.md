# Functional & Non-Functional Requirements — Instrumentation Demo

## Functional Requirements
- **FR-1.** The demo **must** provide a fixed, simulated event set with:
  - sessions_total = 5
  - iterations_completed = 3
  - safe_exports = 4
  - resumes_successful = 2
- **FR-2.** The demo **must** generate a Markdown “Mini Engagement Dashboard” file showing totals, a 7-day trend table, and key insights.
- **FR-3.** The demo **must** include a prominent privacy banner: “Simulated, local-only dataset. No personal identifiers.”
- **FR-4.** The demo **must** document the computation rules for derived insights (e.g., completion rate = completions / sessions).
- **FR-5.** Packaging **must** include all demo artifacts.

## Non-Functional Requirements
- **NFR-1.** Zero external network calls.
- **NFR-2.** All artifacts human-readable (Markdown + JSON).
- **NFR-3.** Re-running the demo **must** yield identical outputs (deterministic).
- **NFR-4.** Dashboard rendering **must** complete in < 1s on typical hardware (spec-only).
- **NFR-5.** Privacy: no content-level logging, no identifiers, timestamps only.
