# Data Model — Instrumentation Demo

## Files
- `metrics_demo.json` — deterministic simulated dataset.
- `dashboard_demo.md` — Mini Engagement Dashboard (Markdown).
- `provenance.md` — explains how demo events map to totals.

## metrics_demo.json (simulated)
```json
{
  "tracking_enabled": true,
  "sessions_total": 5,
  "iterations_completed": 3,
  "safe_exports": 4,
  "resumes_successful": 2,
  "events": [
    {"ts": "2025-10-12T10:00:00Z", "type": "new_iteration_started"},
    {"ts": "2025-10-12T10:20:00Z", "type": "iteration_completed"},
    {"ts": "2025-10-12T10:25:00Z", "type": "safe_export"},
    {"ts": "2025-10-13T09:10:00Z", "type": "new_iteration_started"},
    {"ts": "2025-10-13T10:00:00Z", "type": "safe_export"},
    {"ts": "2025-10-14T08:45:00Z", "type": "resume_success"},
    {"ts": "2025-10-14T09:00:00Z", "type": "iteration_completed"},
    {"ts": "2025-10-15T11:30:00Z", "type": "new_iteration_started"},
    {"ts": "2025-10-15T11:50:00Z", "type": "safe_export"},
    {"ts": "2025-10-16T14:15:00Z", "type": "new_iteration_started"},
    {"ts": "2025-10-16T14:35:00Z", "type": "iteration_completed"},
    {"ts": "2025-10-17T16:00:00Z", "type": "safe_export"},
    {"ts": "2025-10-18T09:05:00Z", "type": "resume_success"},
    {"ts": "2025-10-18T09:10:00Z", "type": "new_iteration_started"}
  ],
  "last_event": "new_iteration_started",
  "last_updated": "2025-10-18T09:10:00Z"
}
```

## Derived Metrics (computed rules)
- `completion_rate = iterations_completed / sessions_total` (rounded to 2 decimals).
- `export_per_session = safe_exports / sessions_total` (2 decimals).
- `resume_ratio = resumes_successful / sessions_total` (2 decimals).
- 7-day trend: counts per day grouped by `events[].ts` date.

## dashboard_demo.md (structure)
- Title + privacy banner
- KPI cards: Sessions, Completions, Completion Rate, Safe Exports, Resumes
- 7-day trend table (date, sessions+, completions+, exports+, resumes+)
- Key insights (bullets referencing FR-4 rules)
