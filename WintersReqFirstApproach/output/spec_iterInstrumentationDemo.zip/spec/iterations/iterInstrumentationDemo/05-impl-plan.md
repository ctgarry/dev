# Implementation Plan — Instrumentation Demo

## Touchpoints
- `/demo/metrics_demo.json` — simulated dataset.
- `/demo/dashboard_demo.md` — rendered dashboard.
- `/demo/provenance.md` — mapping of events → totals.
- `/README_RECOVERY.txt` — already present via Safety-Net.

## Steps (≤6 small steps)
1. Create deterministic `metrics_demo.json` with fixed timestamps and event types (FR-1).
2. Define computation rules (FR-4) and apply them to produce totals and ratios.
3. Render `dashboard_demo.md` with privacy banner (FR-3) and KPI section (FR-2).
4. Render 7-day trend table from events (FR-2).
5. Write `provenance.md` explaining event → total mappings.
6. Include `/demo/*` in Safety-Net packaging (FR-5).
