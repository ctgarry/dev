# i18n Keys — Instrumentation Demo (enUS intent)

```lua
L.DEMO_PRIVACY = "Simulated, local-only dataset. No personal identifiers."
L.DEMO_TITLE   = "Mini Engagement Dashboard — Demo"
L.DEMO_KPI_SES = "Sessions"
L.DEMO_KPI_CMP = "Completions"
L.DEMO_KPI_CRT = "Completion Rate"
L.DEMO_KPI_EXP = "Safe Exports"
L.DEMO_KPI_RES = "Resumes"
L.DEMO_TREND   = "7-Day Trend"
L.DEMO_INSIGHTS= "Key Insights"
L.DEMO_PROV    = "Provenance"
```
