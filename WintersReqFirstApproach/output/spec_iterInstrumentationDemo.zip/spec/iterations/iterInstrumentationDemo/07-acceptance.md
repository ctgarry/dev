# Acceptance Criteria — Instrumentation Demo

| ID | Description | Verification |
|----|-------------|--------------|
| FR-1 | Simulated dataset values | `sessions_total=5`, `iterations_completed=3`, `safe_exports=4`, `resumes_successful=2` appear in metrics_demo.json |
| FR-2 | Dashboard KPIs render | `dashboard_demo.md` shows totals and computed ratios |
| FR-3 | Privacy banner present | First lines of dashboard include L.DEMO_PRIVACY |
| FR-4 | Computation rules documented | dashboard and provenance both explain formulas |
| FR-5 | Packaging includes demo files | `/demo/*` exists in exported ZIP |

**Derived Values (expected):**
- completion_rate = 3/5 = **0.60**
- export_per_session = 4/5 = **0.80**
- resume_ratio = 2/5 = **0.40**
