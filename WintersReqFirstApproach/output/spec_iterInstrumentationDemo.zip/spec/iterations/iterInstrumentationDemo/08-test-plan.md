# Test Plan — Instrumentation Demo

## Smoke
- Open dashboard → verify privacy banner and KPI totals.
- Open provenance → verify event→total mapping.

## Functional
1. Verify `metrics_demo.json` contains required counts (FR-1).
2. Validate dashboard shows completion_rate=0.60, export_per_session=0.80, resume_ratio=0.40 (FR-2, FR-4).
3. Confirm 7-day trend table lists each date present in events, ascending, with correct per-day counts (FR-2).
4. Confirm demo files included in ZIP (FR-5).

## Edge Cases
- If any required field missing → dashboard should state “Demo data incomplete.”
- If timestamps fall outside 7 days → list them in “Out-of-window events” appendix.

## Performance
- Rendering spec must remain human-readable; no heavy assets.

## Privacy
- Confirm no personal identifiers or content sampled.
