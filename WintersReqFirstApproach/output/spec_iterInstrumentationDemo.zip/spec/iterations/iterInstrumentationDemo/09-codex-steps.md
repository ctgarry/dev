# Codex Steps — Instrumentation Demo (Strict Light-Diff)

1. ADD `demo/metrics_demo.json` (deterministic payload).
2. ADD `demo/dashboard_demo.md` (Markdown with banner, KPIs, trend).
3. ADD `demo/provenance.md` (events → totals mapping).
4. UPDATE packaging rules to include `/demo/*` files.
5. STOP & WAIT — verify KPIs equal simulated totals and ratios.
