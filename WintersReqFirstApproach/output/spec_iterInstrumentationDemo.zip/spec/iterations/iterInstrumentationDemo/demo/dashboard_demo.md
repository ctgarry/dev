# Mini Engagement Dashboard — Demo
> **Simulated, local-only dataset. No personal identifiers.**

## KPIs
- **Sessions:** 5
- **Completions:** 3
- **Completion Rate:** 0.6
- **Safe Exports:** 4
- **Resumes:** 2
- **Exports / Session:** 0.8
- **Resume Ratio:** 0.4

## 7-Day Trend
| Date | Sessions | Completions | Safe Exports | Resumes |
|------|----------|-------------|--------------|---------|
| 2025-10-12 | 1 | 1 | 1 | 0 |
| 2025-10-13 | 1 | 0 | 1 | 0 |
| 2025-10-14 | 0 | 1 | 0 | 1 |
| 2025-10-15 | 1 | 0 | 1 | 0 |
| 2025-10-16 | 1 | 1 | 0 | 0 |
| 2025-10-17 | 0 | 0 | 1 | 0 |
| 2025-10-18 | 1 | 0 | 0 | 1 |


## Key Insights
- Completion rate indicates **60%** of sessions reached all 00–09 files.
- Users exported safely **0.80** times per session on average.
- Resume activity suggests **40%** of sessions involved returning users.
- Activity is spread across multiple days, indicating ongoing usage.

## Privacy & Provenance
- This dashboard is generated from a deterministic simulated dataset (`demo/metrics_demo.json`).
- No real user data is included.
