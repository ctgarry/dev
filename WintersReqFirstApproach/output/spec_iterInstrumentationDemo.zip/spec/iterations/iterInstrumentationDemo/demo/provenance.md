# Provenance — Instrumentation Demo

This document explains how each metric on the dashboard is derived from simulated events.

## Source
- File: `demo/metrics_demo.json`

## Mapping
- **Sessions** = count of `new_iteration_started` events.
- **Completions** = count of `iteration_completed` events.
- **Safe Exports** = count of `safe_export` events.
- **Resumes** = count of `resume_success` events.
- **Completion Rate** = Completions / Sessions.
- **Exports / Session** = Safe Exports / Sessions.
- **Resume Ratio** = Resumes / Sessions.

## Determinism
- Timestamps are fixed ISO 8601 dates in the week of 2025-10-12 to 2025-10-18.
- Re-generating this demo yields identical results.
