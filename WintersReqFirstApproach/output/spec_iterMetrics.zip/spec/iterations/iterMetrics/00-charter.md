# Iteration: Engagement Tracker Specification

## Problem
ProjectGPT currently has no structured way to measure user engagement or workflow depth.  
Without telemetry, we cannot evaluate whether users complete iterations, resume projects, or trust Safety-Net Mode.

## Vision
Provide a safe, local-only engagement tracker that logs meaningful metrics (sessions, completions, resumes, exports)  
— without ever capturing private content or identifiers.

## Scope
- **In scope:** Logging iteration events, producing local summaries, user opt-in telemetry, export metrics.
- **Out of scope:** Cloud analytics, message-level telemetry, or user identifiers.

## Non-goals
- No network transmission or remote tracking.
- No persistent storage outside user ZIPs.

## Constraints
- Must integrate with Safety-Net workflow.
- Logs must be human-readable and machine-parseable (Markdown + JSON).

## Personas
- **Builder:** Uses ProjectGPT to generate specs; wants to know progress.
- **Maintainer:** Audits engagement levels to improve usability.
- **User:** Must feel safe knowing telemetry is local and voluntary.

## Success Criteria
- 100% local data ownership.
- Zero external dependencies.
- Clear “Enable/Disable Tracking” UX state.
