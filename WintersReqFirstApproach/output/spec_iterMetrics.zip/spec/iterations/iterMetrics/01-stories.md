# User Stories — Engagement Tracker

## Story 1 — Enable Tracking
**As a** user  
**I want** to opt-in to engagement tracking  
**So that** my session and iteration progress can be summarized locally.

### Acceptance Criteria
- Given tracking is disabled by default,  
  When user types "Enable engagement tracking",  
  Then system must confirm and create a local `metrics/` folder.

---

## Story 2 — Log Session Start
**As a** builder  
**I want** ProjectGPT to record when an iteration begins  
**So that** total session counts are accurate.

### Acceptance Criteria
- On creation of 00-charter.md, log event `new_iteration_started`.

---

## Story 3 — Track Completion
**As a** builder  
**I want** ProjectGPT to record when all 00–09 files are generated  
**So that** completion rates can be reported.

### Acceptance Criteria
- On generation of 09-codex-steps.md, log event `iteration_completed`.

---

## Story 4 — Record Safe Export
**As a** user  
**I want** each “Package this iteration” action logged  
**So that** I can audit my save frequency.

### Acceptance Criteria
- Each export increments `safe_export_count` in metrics.json.

---

## Story 5 — Resume Tracking
**As a** returning user  
**I want** resumed iterations to update my metrics  
**So that** I can measure project longevity.

### Acceptance Criteria
- On zip reload, log event `resume_success` with timestamp.
