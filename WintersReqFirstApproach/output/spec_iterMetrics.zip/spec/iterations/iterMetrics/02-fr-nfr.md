# Functional & Non-Functional Requirements

## Functional Requirements
- **FR-1.** When tracking is enabled, system **must** create `metrics/metrics.json` and `metrics/summary.md`.
- **FR-2.** When user generates 00-charter.md, system **must** log `new_iteration_started`.
- **FR-3.** When 09-codex-steps.md is produced, system **must** log `iteration_completed`.
- **FR-4.** When user exports iteration, system **must** increment `safe_export_count`.
- **FR-5.** When iteration zip is reloaded, system **must** log `resume_success`.
- **FR-6.** User **must** be able to disable tracking anytime with “Disable engagement tracking.”

## Non-Functional Requirements
- **NFR-1.** All logs must remain local (no external API or storage).
- **NFR-2.** Data files must be human-readable (Markdown + JSON).
- **NFR-3.** Tracker initialization must not slow normal iteration creation by more than 5%.
- **NFR-4.** Data must persist through Safety-Net exports and imports.
- **NFR-5.** Privacy guarantee: no content, timestamps only.
