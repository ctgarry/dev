# Data Model — Engagement Tracker

## Entities

### `metrics.json`
```json
{
  "tracking_enabled": true,
  "sessions_total": 0,
  "iterations_completed": 0,
  "safe_exports": 0,
  "resumes_successful": 0,
  "last_event": "",
  "last_updated": ""
}
```

### `summary.md`
| Metric | Description | Example |
|--------|--------------|----------|
| Sessions | Number of iteration starts | 4 |
| Completions | Full 00–09 sets generated | 2 |
| Safe Exports | Number of packaged zips | 5 |
| Resumes | Times iteration reloaded | 3 |
| Last Updated | Timestamp | 2025-10-19 15:24 UTC |
