# Implementation Plan — Engagement Tracker

## Touchpoints
- `/metrics/metrics.json` — local event storage.
- `/metrics/summary.md` — human-readable report.
- `/README_RECOVERY.txt` — include tracking mention.

## Steps
1. Add opt-in command: “Enable engagement tracking.”
2. Create `/metrics` folder with initial JSON and Markdown.
3. Hook event logger into iteration creation/export/resume.
4. Update summary file after each event.
5. Ensure packaging includes `/metrics/`.
6. Add “Disable engagement tracking” toggle.
