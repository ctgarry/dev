# i18n Keys — Engagement Tracker (enUS intent)

```lua
L.TRACKING_ENABLED  = "Engagement tracking enabled — local only."
L.TRACKING_DISABLED = "Engagement tracking disabled."
L.METRICS_UPDATED   = "Metrics updated."
L.METRICS_SUMMARY   = "Engagement summary available in metrics/summary.md."
L.EXPORT_LOGGED     = "Safe export logged."
L.RESUME_LOGGED     = "Resume event logged."
```
