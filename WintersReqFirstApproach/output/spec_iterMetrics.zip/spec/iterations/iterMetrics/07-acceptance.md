# Acceptance Criteria — Engagement Tracker

| ID | Description | Verification |
|----|--------------|---------------|
| FR-1 | Metrics folder created on opt-in | File exists: `/metrics/metrics.json` |
| FR-2 | Session logged at charter creation | JSON contains `sessions_total++` |
| FR-3 | Completion logged at codex steps | JSON contains `iterations_completed++` |
| FR-4 | Export logged on packaging | JSON contains `safe_exports++` |
| FR-5 | Resume logged on reload | JSON contains `resumes_successful++` |
| FR-6 | Disable tracking works | JSON field `"tracking_enabled": false` |
| NFR-1 | No network calls detected | Static audit |
| NFR-4 | Metrics persist across zips | Recovery test passed |
