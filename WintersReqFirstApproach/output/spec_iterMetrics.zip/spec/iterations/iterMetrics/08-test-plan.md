# Test Plan — Engagement Tracker

## Smoke Tests
- Enable → confirm folder creation.
- Disable → confirm status change.

## Functional Tests
1. Generate 00-charter.md → check `sessions_total`.
2. Generate 09-codex-steps.md → check `iterations_completed`.
3. Export iteration → check `safe_exports`.
4. Reload from ZIP → check `resumes_successful`.

## Edge Cases
- Enable twice → no duplicate folders.
- Disable mid-session → stops logging.
- Corrupted JSON → regenerate clean file.

## Performance Tests
- Ensure <5% latency overhead during event logging.

## Privacy Tests
- Confirm no sensitive content in logs.
