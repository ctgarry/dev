# Codex Steps — Engagement Tracker

1. Add command handler for "Enable/Disable engagement tracking".
2. Create `/metrics/` folder if enabled.
3. On iteration start → append event `new_iteration_started`.
4. On iteration completion → append event `iteration_completed`.
5. On safe export → increment `safe_exports`.
6. On reload → append `resume_success`.
7. Generate `summary.md` report.
8. Include metrics in Safety-Net ZIP.
9. Confirm NFR compliance (no external transmission).
